VIVEK-ASI-OMEGA NEXUS static website
Upload index.html to the root of a GitHub repository and enable GitHub Pages.
This is a static dossier: it cannot run Python/pytest tests on the hosted website.
Re-run the Colab generator after project changes to refresh inventory and saved reports.
Review the website before publishing; do not expose secrets, credentials, or private files.
